<!DOCTYPE html>
<html lang="en">
    <table class=tt>
<thead>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=@, initial-scale=1.0">
    <link rel="stylesheet" href="../app.css">
    <title>Таблица</title>

<h1><center>Таблица учеников </center></h1>
<tr>
    <th>id</th>
    <th>имя ученика</th>
    <th>возраст</th>
    <th>дата рождения</th>
</tr>
</thead>
<tbody>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
   <td><?php echo e($post->id); ?></td>
   <td><?php echo e($post->name); ?></td>
   <td><?php echo e($post->vozrast); ?></td>
   <td><?php echo e($post->data); ?></td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</html><?php /**PATH /home/adminmurash/laravelapp/resources/views/studTable.blade.php ENDPATH**/ ?>