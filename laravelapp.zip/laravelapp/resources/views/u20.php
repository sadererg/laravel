<head>
<header>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <div class="menu">
    <ul>
        <link rel="stylesheet" href="./app.css">
        
        <li><a href ="/">АПТ</li>
        <li><a href ="/about">О техникуме</li>
        <li><a href ="/contact">контакты</li>
        <li><a href ="/u20">И-20</a></li>
        <li><a href ="ychTable">таблица учителей</a></li>
        <li><a href ="studTable">таблица учеников</a></li>
            </ul>
     </div>
</header>
   <body>
   
   
<div class="site-index">


    <div class="jumbotron text-center bg-transparent">
        <h1 class="display-4">О И-20</h1>
     

        </p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                
                <p><img src="./11.jpg" width="500" height="500"><img src="./12.jpg" width="500" height="500"></p>
                <p>
                ППрограммист – это специалист, создающий исходный код для программы. Такой программой может быть операционная система компьютера, видеоигра, web или мобильное приложение и даже алгоритм работы микроволновки. Программный код пишется на специальном языке программирования. Он состоит из обычных слов и некоторых специальных символов. Сегодня насчитывается несколько сотен языков программирования, но самые распространенные из них – Java, Python, PHP, C#, JavaScript, C, С++, Objective-C, Swift. Какой язык программирования выбрать, программист решает сам в зависимости от конкретной задачи (сделать игру, приложение для web или программу для сервера) и собственных знаний. Квалифицированный программист уверенно использует 2-4 языка. </p>

                
            </div>
            <div class="col-lg-4">
                
<p>
            </div>
        </div>

    </div>
</div>
  </body>
  </head>
</html>