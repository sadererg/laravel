<head>
<header>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <div class="menu">
    <ul>
        <link rel="stylesheet" href="./app.css">
        
        <li><a href ="/">АПТ</li>
        <li><a href ="/about">О техникуме</li>
        <li><a href ="/contact">контакты</li>
        <li><a href ="/u20">И-20</a></li>
        <li><a href ="ychTable">таблица учителей</a></li>
        <li><a href ="studTable">таблица учеников</a></li>
            </ul>
     </div>
</header>
   <body>
   
<div class="site-index">


    <div class="jumbotron text-center bg-transparent">
        <h1 class="display-4">Контакты</h1>
     

        </p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                
                <p><img src="./6.jpg" width="50" height="50"> <img src="./7.jpg" width="50" height="50"> <img src="./8.jpg" width="50" height="50"><img src="./9.jpg" width="50" height="50"><img src="./10.jpg" width="50" height="50"></p>
                <p>КАК С НАМИ СВЯЗАТЬСЯ:</p>
                <p>Ангарский политехнический техникум находится по адресу:</p>
                <p>665830, Иркутская область, город Ангарск, 52 квартал, дом 1</p>
                <p>Телефон приемной комиссии: (3955)51-21-04</p>
                <p>Телефон факс секретаря: (3955) 52-20-60</p>
                <p>Адрес электронной почты: apt@aptangarsk.ru</p>
                <p>Официальный сайт техникума: aptangarsk.ru</p>
                
            </div>
         
        </div>

    </div>
</div>
  </body>
  </head>
</html>